# The Woman You Are

A full functional static website for **The Woman You Are** — a poetic tribute website designed to appreciate women as mothers, sisters, daughters, wives, and simply as women.

## What is included

```text
index.html
stories.html
assets/
  css/styles.css
  js/main.js
  images/hero-woman.svg
content/
  mother.html
  sister.html
  daughter.html
  wife.html
  woman.html
stories/
  story-001.html
  story-002.html
  story-003.html
  story-template.html
README.md
```

## Replace these placeholders

Search all files for:

```text
YOUR_STRIPE_PAYMENT_LINK
YOUR_FORMSPREE_ENDPOINT
```

Replace:

- `YOUR_STRIPE_PAYMENT_LINK` with your Stripe Payment Link.
- `YOUR_FORMSPREE_ENDPOINT` with your Formspree form endpoint.

## How to edit letters

Edit these files:

```text
content/mother.html
content/sister.html
content/daughter.html
content/wife.html
content/woman.html
```

The homepage automatically loads them into the popups.

## How to add a new story

1. Duplicate:

```text
stories/story-template.html
```

2. Rename it:

```text
stories/story-004.html
```

3. Edit the story text.

4. In `stories.html`, duplicate one story card and one modal block, then update:
   - person name
   - title
   - preview text
   - modal ID
   - story file path

## Important local testing note

Because the website loads HTML content using JavaScript `fetch()`, opening `index.html` directly from your computer may block the content popups.

Use one of these:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

Or deploy to GitHub Pages.

## GitHub Pages deployment

1. Upload all files to your repository.
2. Go to repository **Settings**.
3. Open **Pages**.
4. Source: **Deploy from branch**.
5. Branch: `main`.
6. Folder: `/root`.
7. Save.

Your URL should look like:

```text
https://khalil93ayoub.github.io/the-woman-you-are/
```

## Recommended setup

- Donations: Stripe Payment Link
- Forms: Formspree free plan
- Stories: manual approval before publishing
